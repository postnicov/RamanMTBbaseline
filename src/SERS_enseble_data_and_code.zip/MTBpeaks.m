clear;close all;clc;FS=10;

SG=21;

%% Assigning susseptibility classes 
list_of_files;
N=length(file);
for j=1:N;
    CLS(j,1)=~isempty(strfind(file{j},'sens'));
    CLS(j,2)=~isempty(strfind(file{j},'mdr'));
    CLS(j,3)=~isempty(strfind(file{j},'xdr'));
end
CLS=double(CLS);
%%
for j=1:N;     
    S=csvread(file{j});
    S=sortrows(S);
    nu = S(:,1);
    Sraw = S(:,2);
    [pks,locs,w,p] = findpeaks(Sraw,'MinPeakProminence',1);
    %

    Mp=0.5*median(p);
    ind1=find((nu(locs)>=725)&(nu(locs)<=735)&p>Mp);
    CLS(j,4)=length(ind1);
    ind2=find((nu(locs)>=742)&(nu(locs)<=752)&p>Mp);
    CLS(j,5)=length(ind2);
    ind3=find((nu(locs)>=1165)&(nu(locs)<=1175)&p>Mp);
    CLS(j,6)=length(ind3);
end

figure
is=find(CLS(:,1)==1);
isL=length(is);
ist = tinv(0.95,isL);
im=find(CLS(:,2)==1);
imL=length(im);
imt = tinv(0.95,isL);
ix=find(CLS(:,3)==1);
ixL=length(ix);
ixt = tinv(0.95,ixL);
%
errorbar([1 2 3],...
    [mean(CLS(is,4)),mean(CLS(im,4)),mean(CLS(ix,4))],...
    [ist*std(CLS(is,4))/sqrt(isL),...
    imt*std(CLS(im,4))/sqrt(imL),...
    ixt*std(CLS(ix,4))/sqrt(ixL)],...
    'o:','MarkerSize',9,'LineWidth',1.2,'color','blue')
hold on
errorbar([1 2 3],...
    [mean(CLS(is,5)),mean(CLS(im,5)),mean(CLS(ix,5))],...
    [1.96*std(CLS(is,5))/sqrt(length(is)),...
    1.96*std(CLS(im,5))/sqrt(length(is)),...
    1.96*std(CLS(ix,5))/sqrt(length(ix))],...
    'x:','MarkerSize',8,'LineWidth',1,'color','black')
errorbar([1 2 3],...
    [mean(CLS(is,5)),mean(CLS(im,5)),mean(CLS(ix,5))],...
    [1.96*std(CLS(is,6))/sqrt(length(is)),...
    1.96*std(CLS(im,6))/sqrt(length(is)),...
    1.96*std(CLS(ix,6))/sqrt(length(ix))],...
    '+:','MarkerSize',8,'LineWidth',1,'color','red')
ylim([0.15 1.2])
legend({'$730 \pm 5~\mathrm{cm^{-1}}$',...
        '$747 \pm 5~\mathrm{cm^{-1}}$',...
        '$1170 \pm 5~\mathrm{cm^{-1}}$'},...
    'Location','SouthEast','Interpreter','Latex')
ylabel('Mean occurence of lines',...
    'Interpreter','Latex')
set(gca,'XTick',[1 2 3],'XTickLabel',{'Sens','MDR','XDR'})
set(gca,'FontSize',FS,'FontName','Times')

set(gcf,'PaperUnits','centimeters','PaperPosition',[0 0 12 8],'PaperSize',[12 8])
print('FigPeaksStat','-dpng','-r300')