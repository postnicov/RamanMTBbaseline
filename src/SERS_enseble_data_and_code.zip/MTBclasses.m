clear;close all;clc;FS=10;

bins=450:100:1450;

%% Assigning susseptibility classes 
list_of_files;
N=length(file);
for j=1:N;
    CLS(j,1)=~isempty(strfind(file{j},'sens'));
    CLS(j,2)=~isempty(strfind(file{j},'mdr'));
    CLS(j,3)=~isempty(strfind(file{j},'xdr'));
    CLS(j,4)=~isempty(strfind(file{j},'extrapul'));
end
CLS=double(CLS);
%%
for j=1:N;     
    S=csvread(file{j});
    S=sortrows(S);
    nu = S(:,1);
    Sraw = S(:,2);
    [pks,locs,w,p] = findpeaks(Sraw,'MinPeakProminence',1);
    %
    Mp=0.5*median(p);
    ind=find((p>Mp)&(p<100*Mp));
    locs=locs(ind);
    h(j,:)=hist(nu(locs),bins);
end
h=h(:,10);

Z = linkage(h,'ward');
NX=1:N;
figure
ddr=dendrogram(Z,0);
set(ddr,'LineWidth',2,'color','blue');
inds=find(CLS(:,1)>0);
indm=find(CLS(:,2)>0);
indx=find(CLS(:,3)>0);
%
% get the current tick labeks
ticklabels = get(gca,'XTickLabel');
% prepend a color for each tick label
ticklabels_new = cell(length(ticklabels),1);
hold on
indep=find(CLS(:,4)>0);
for i=1:length(indep);
    mrk{indep(i)}='*';
end
indep1=find(CLS(:,4)==0);
for i=1:length(indep1);
    mrk{indep1(i)}='o';
end
%
for i = 1:length(inds)
    clr{inds(i)}='green';
end
for i = 1:length(indm)
    clr{indm(i)}='black';
end
for i = 1:length(indx)
    clr{indx(i)}='red';
end
%
for j=1:N
    plot(j,0,'Marker',mrk{j},'color',clr{j},'MarkerSize',3,'LineWidth',0.5)
end

% set the tick labels
set(gca, 'XTickLabel', ticklabels_new);
box
set(gca,'FontSize',FS,'FontName','Times')
ylabel('Inner squared distance','FontSize',FS)
xlabel('Elements of the dataset','FontSize',FS)

set(gcf,'PaperUnits','centimeters','PaperPosition',[0 0 12 6],'PaperSize',[12 6])
print('FigDendro','-dpng','-r300')